import asyncio
from telethon import TelegramClient, events
import requests

api_id = #your api_id
api_hash = 'your api_hash'
session_name = 'my_session'
trip_bot_username = 'bot or user'

bot_token = 'TOKEN BOT'
target_chat_ids = [#user id's]

def forward_message_to_chats(text):
    for chat_id in target_chat_ids:
        url = f'https://api.telegram.org/bot{bot_token}/sendMessage'
        data = {'chat_id': chat_id, 'text': text}
        try:
            r = requests.post(url, data=data, timeout=5)
            if r.status_code != 200:
                print(f'Failed to send to {chat_id}: {r.text}')
        except requests.exceptions.Timeout:
            print(f'Timeout when sending to {chat_id}')
        except Exception as e:
            print(f'Exception sending to {chat_id}: {e}')

async def main():
    client = TelegramClient(session_name, api_id, api_hash)
    await client.start()
    print('Listening messages...')

    @client.on(events.NewMessage(from_users=trip_bot_username))
    async def handler(event):
        msg = event.message.message
        forward_message_to_chats(msg)

    await client.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(main())
